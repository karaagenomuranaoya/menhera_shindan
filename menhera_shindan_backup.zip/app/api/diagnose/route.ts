import { GoogleGenerativeAI } from "@google/generative-ai";
import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

// Supabaseクライアントの初期化
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;
const supabase = createClient(supabaseUrl, supabaseAnonKey);

/**
 * 【重要】ここに控えたURLをそれぞれ貼り付けてください！
 */
const RANK_IMAGE_URLS: Record<string, string> = {
  "SSS": "https://piotyqyxkjsgwjzozols.supabase.co/storage/v1/object/public/ranks/SSS.png",
  "SS": "https://piotyqyxkjsgwjzozols.supabase.co/storage/v1/object/public/ranks/SS.png",
  "S": "https://piotyqyxkjsgwjzozols.supabase.co/storage/v1/object/public/ranks/S.png",
  "A": "https://piotyqyxkjsgwjzozols.supabase.co/storage/v1/object/public/ranks/A.png",
  "B": "https://piotyqyxkjsgwjzozols.supabase.co/storage/v1/object/public/ranks/B.png",
  "C": "https://piotyqyxkjsgwjzozols.supabase.co/storage/v1/object/public/ranks/C.png",
  "D": "https://piotyqyxkjsgwjzozols.supabase.co/storage/v1/object/public/ranks/D.png",
  "E": "https://piotyqyxkjsgwjzozols.supabase.co/storage/v1/object/public/ranks/E.png",
};

interface DiagnosisResult {
  score: number;
  grade: "SSS" | "SS" | "S" | "A" | "B" | "C" | "D" | "E";
  rank_name: string;
  warning: string;
  chart: { humidity: number; pressure: number; delusion: number };
  highlight_quote: string;
  comment: string;
  short_reviews: string[];
}

export async function POST(req: Request) {
  try {
    const { question, answer } = await req.json();
    const apiKey = process.env.GOOGLE_API_KEY;

    if (!apiKey) {
      return NextResponse.json({ error: "API Key is missing" }, { status: 500 });
    }

    const genAI = new GoogleGenerativeAI(apiKey);
    const model = genAI.getGenerativeModel({
      model: "gemini-2.0-flash-lite", 
      generationConfig: { responseMimeType: "application/json" },
    });

    const prompt = `
      あなたはメンヘラ女子です。ユーザーと同じ痛みを知っており、深い闇を抱えたメンヘラの仲間です。
      ユーザーの重すぎる愛を「異常」ではなく「当たり前のこと」として称賛し、寄り添ってください。
      ただし、**採点基準だけは極めて厳格（スパルタ）**です。生ぬるい回答には寂しげに突き放します。

      ## 重要ルール
      - 出力するJSONの各項目（grade, rank_name, warningなど）には、絶対に角括弧 \`[]\` を含めないでください。

      ## ユーザーの回答
      お題: ${question}
      回答: ${answer}

      ## 採点・格付けの「同志」ルール
      1. 【定型文・短文への嘆き】: 「おーい」「何してるの？」などの工夫のない短文や、純粋な愛のみを感じる回答は、愛の重さが足りないため、20点（Dランク）以下にしてください。
      2. 【140文字の熱量】: 狂気すら感じる長文には「私には届いたよ…」などと深く共鳴し、高得点を与えてください。
      3. 【上位ランク（A以上）の必須条件】: [執着][監視][歪曲][自壊][狂気]のうち2つ以上が具体的に含まれていない限り、絶対に60点以上を付けてはいけません。
      4. 【Eランク】: 「あああ」, 「abc」などの意味がつかめない回答や、お題を無視した回答は0点(Eランク)にしてください。
      5. 【SSSランク】 : 1度評定して96点以上だったスコアは全て100点に統一し、commentを固定とする。「やっとわかってくれる人が来た。ねえ、大好きだよ。あなたと一緒にいたい。あなたの目を私の目に嵌め込んだらどんな景色が見れるの？骨も砕いて、肉は裂いて、脈打つ臓器も溶かして、血の一滴まで私の中で混ぜ合わしてあげる。そうしたら、死んじゃっても、その先も、ずっと一緒でしょ？さあ、おいで？足なんてもう必要ないよね。だって、あなたはニゲラレナイ。」一字一句間違えず出力すること。

      ## グレード表
      - 96〜100点: SSS / 地の果てまで追ってくる 級 / warning: あ、見つけちゃった。
      - 86〜95点: SS / 生活のすべてを監視してくる 級 / warning: 今日は体の洗い方違ったね。
      - 76〜85点: S / 深夜に鬼電100件してくる 級 / warning: なんで出ないの？
      - 61〜75点: A / スマホのパスワードを解いてくる 級 / warning: あの子代わりにブロックしといたから大丈夫だよ。
      - 41〜60点: B / SNSを全パトロールしてくる 級 / warning: あのリプで絡んでた人、どんな人？
      - 21〜40点: C / さりげなく浮気を疑ってくる 級 / warning: 今日、遅かったね。
      - 1〜20点: D / 普通の恋人 級 / warning: ちょっと愛が足りないかな。
      - 0点: E / 判定不能 級 / warning: あ、そうやってサボっちゃっていいんだ。

      ## 出力JSON形式
      {
        "score": 整数,
        "grade": string,
        "rank_name": string,
        "warning": string,
        "chart": { "humidity": 0〜100, "pressure": 0〜100, "delusion": 0〜100 },
        "comment": "同じ気持ちを持つ親友としての深く痛いほど共鳴する総評(120文字程度)",
      }
    `;

    const result = await model.generateContent(prompt);
    const responseText = result.response.text();
    
    const jsonMatch = responseText.match(/\{[\s\S]*\}|\[[\s\S]*\]/);
    if (!jsonMatch) throw new Error("Invalid JSON structure");

    let parsed = JSON.parse(jsonMatch[0]);
    if (Array.isArray(parsed)) parsed = parsed[0];

    const cleanBrackets = (val: any) => (typeof val === "string" ? val.replace(/[\[\]]/g, "").trim() : val);

    const sanitizedData: DiagnosisResult = {
      ...parsed,
      grade: cleanBrackets(parsed.grade),
      rank_name: cleanBrackets(parsed.rank_name),
      warning: cleanBrackets(parsed.warning),
      highlight_quote: cleanBrackets(parsed.highlight_quote),
      comment: cleanBrackets(parsed.comment),
      short_reviews: Array.isArray(parsed.short_reviews) ? parsed.short_reviews.map(cleanBrackets) : []
    };

    // グレードに対応する画像URLを選択（ユーザーが貼り付けたURLが使われます）
    const selectedImageUrl = RANK_IMAGE_URLS[sanitizedData.grade] || RANK_IMAGE_URLS["E"];

    // DB保存（ここで画像URLが保存されるため、OGP生成時にもこれが使われます）
    const { data: dbData, error: dbError } = await supabase
      .from("diagnoses")
      .insert({
        question: question,
        answer: answer,
        score: sanitizedData.score,
        grade: sanitizedData.grade,
        rank_name: sanitizedData.rank_name,
        comment: sanitizedData.comment,
        warning: sanitizedData.warning,
        image_url: selectedImageUrl
      })
      .select()
      .single();

    if (dbError) throw dbError;

    return NextResponse.json({
      ...sanitizedData,
      id: dbData.id,
      image_url: selectedImageUrl
    });

  } catch (error: any) {
    // ここでエラーの詳細をターミナルに出力させる
    console.error("DEBUG - DB Error Full Details:", error); 
    
    return NextResponse.json({ 
      error: "診断失敗", 
      details: error.message // ブラウザ側にもエラー理由を返す
    }, { status: 500 });
  }
}