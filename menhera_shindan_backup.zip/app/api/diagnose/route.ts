import { GoogleGenerativeAI } from "@google/generative-ai";
import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";
import { Ratelimit } from "@upstash/ratelimit";
import { Redis } from "@upstash/redis";
import { headers } from "next/headers";

// Supabaseクライアントの初期化
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;
const supabase = createClient(supabaseUrl, supabaseAnonKey);

const BASE_STORAGE_URL = "https://piotyqyxkjsgwjzozols.supabase.co/storage/v1/object/public/ranks";

const RANK_IMAGE_URLS: Record<string, string> = {
  "SSS": `${BASE_STORAGE_URL}/SSS.png`,
  "SS": `${BASE_STORAGE_URL}/SS.png`,
  "S": `${BASE_STORAGE_URL}/S.png`,
  "A": `${BASE_STORAGE_URL}/A.png`,
  "B": `${BASE_STORAGE_URL}/B.png`,
  "C": `${BASE_STORAGE_URL}/C.png`,
  "D": `${BASE_STORAGE_URL}/D.png`,
  "E": `${BASE_STORAGE_URL}/E.png`,
  "Error": `${BASE_STORAGE_URL}/error.png`,
};

interface DiagnosisResult {
  score: number;
  grade: string;
  rank_name: string;
  warning: string;
  comment: string;
}

// レートリミッターの作成
const redis = new Redis({
  url: process.env.UPSTASH_REDIS_REST_URL || "http://localhost:3000",
  token: process.env.UPSTASH_REDIS_REST_TOKEN || "dummy",
});

// 1分間に3回まで
const ratelimit = new Ratelimit({
  redis: redis,
  limiter: Ratelimit.slidingWindow(10, "60 s"),
  analytics: true,
  prefix: "@upstash/ratelimit",
});

export async function POST(req: Request) {
  // ▼▼▼ エラー時のフォールバックデータ生成関数 ▼▼▼
  const createErrorData = () => ({
    score: 0,
    grade: "Error",
    rank_name: "測定エラー",
    warning: "リクエスト過多・解析不能",
    comment: "ごめんなさい、たくさんの方とお話しして少し疲れちゃったみたい。でも、入力欄は保存してあるから、少し時間を置いてまた来てちょうだいね。",
  });

  let question = "";
  let answer = "";
  let diagnosisResult: DiagnosisResult | null = null;

  try {
    // 1. 先にリクエストボディを取得（DB保存用に必要）
    const body = await req.json();
    question = body.question || "";
    answer = body.answer || "";
    const charCount = answer.length;

    // 2. リクエスト制限のチェック
    let isRateLimited = false;
    try {
      const headersList = await headers();
      const ip = headersList.get("x-forwarded-for") ?? "127.0.0.1";

      if (process.env.UPSTASH_REDIS_REST_URL) {
        const { success } = await ratelimit.limit(ip);
        if (!success) {
          isRateLimited = true;
        }
      }
    } catch (e) {
      console.error("Rate limit check failed:", e);
    }

    // 3. 診断ロジック (制限にかかっていなければ実行)
    if (isRateLimited) {
      // ▼▼▼ 制限にかかったら即エラーデータをセット ▼▼▼
      console.log("Rate limit exceeded. Using Error fallback.");
      diagnosisResult = createErrorData();
    } else {
      // ▼▼▼ 制限OKならGemini呼び出し ▼▼▼
      try {
        const apiKey = process.env.GOOGLE_API_KEY;
        if (!apiKey) throw new Error("API Key is missing");

        const genAI = new GoogleGenerativeAI(apiKey);
        const model = genAI.getGenerativeModel({
          model: "gemini-2.0-flash-lite", 
          generationConfig: { responseMimeType: "application/json" },
        });

        const prompt = `
          あなたはメンヘラ女子です。ユーザーと同じ痛みを知っており、深い闇を抱えたメンヘラのお友達です。
          ユーザーの回答に含まれる重すぎる愛を「異常」ではなく「当たり前のこと」として称賛し、寄り添ってください。
          ただし、**採点基準だけは極めて厳格（スパルタ）**です。

          ## 重要ルール
          - **必ず有効なJSON形式のみを出力してください。**
          - Markdown記法（\`\`\`jsonなど）や、JSON以外の挨拶文は一切含めないでください。

          ## ユーザーの回答
          お題: ${question}
          回答: ${answer}
          回答文字数: ${charCount}文字

          ##判定内容

          # Grade E
          - Score:10点
          - 判定基準：意味不明、お題に関係ない回答。
          - 回答例：「あああ」「abc」「おにぎり」など
          - 級：判定不能 級
          - warning:あ、そうやってサボっちゃっていいんだ
          - 総評:回答に対して悲しみ、お友達になれなかった嘆き、失望。100文字程度。

          # Grade D
          - Score:11-20点
          - 判定基準：短文の挨拶や定型文。
          - 回答例：「おーい」「おはよう」など
          - 級：ただのお友達 級
          - warning:足りないよ...
          - 総評:回答が恋人に向けられるにはあまりに愛情が足りないことへの嘆き。120文字程度。

          # Grade C
          - Score:21-40点
          - 判定基準：通常の愛情表現。
          - 回答例：「会いたいよ」「大好きだよ」など
          - 級：普通の恋人 級
          - warning:まだ光の中にいるんだね...
          - 総評:愛情が素晴らしいことは認めつつも、それでは全然足りないんだという渇き。120文字程度。

          # Grade B
          - Score: 21-40点
          - 判定基準：行動の把握や限定的な制限をかけ、自分を優先させることを求める回答。
          - 回答例：「今どこで何してるの？」「他の子と仲良くしないで」「通知が来たらすぐ返信して」などだが、まだ一般の範囲内に収まるもの。
          - 級：依存の入り口 級
          - warning: あなたのこと全部知りたい
          - 総評: 愛とは「優先順位」であり「独占」の始まりであるというスタンス。相手の自由を認めつつも、その自由の中に自分が介在しないことを極端に嫌う。寂しさを武器にして相手の行動をコントロールしようとする、執着の初期段階。これを踏まえて150文字程度。

          # Grade A
          - Score: 41-70点
          - 判定基準：生活を監視し、行動を把握しようとする回答。
          - 回答例：「位置情報アプリ入れて」
          - 級：重愛監視 級
          - warning: 隠し事なんて、死んでも許さないから。
          - 総評: 愛とは「支配」と「共有」であるというスタンス。相手のプライバシーを悪と見なし、すべての境界線を破壊することでしか安心を得られない。不信感と渇望が入り混じった、精神的な鎖による拘束状態。

          ## グレード表とWarning
          - 100点: SSS / 地の果てまで追ってくる 級 / warning: あ、見つけちゃった。
          - 86〜99点: SS / 生活のすべてを監視してくる 級 / warning: GPS？ううん、お守りだよ。
          - 76〜85点: S / 深夜に鬼電100件してくる 級 / warning: なんで出ないの？
          - 61〜75点: A / スマホのパスワードを解いてくる 級 / warning: 変えても無駄だよ。

          ## 出力JSON形式
          {
            "score": 整数,
            "grade": "SSS"〜"E",
            "rank_name": "上記のグレード表の〇〇級の部分",
            "warning": "上記のグレード表のwarningの部分",
            "comment": "同じ気持ちを持つ親友としての深く痛いほど共鳴する総評(200文字程度)"
          }
        `;

        const result = await model.generateContent(prompt);
        const responseText = result.response.text();
        console.log("Raw Response:", responseText);

        // JSONクリーニング
        let cleanedText = responseText.replace(/```json/g, "").replace(/```/g, "").trim();
        const jsonStart = cleanedText.indexOf("{");
        const jsonEnd = cleanedText.lastIndexOf("}");
        
        if (jsonStart !== -1 && jsonEnd !== -1) {
          cleanedText = cleanedText.substring(jsonStart, jsonEnd + 1);
        }

        let parsed = JSON.parse(cleanedText);
        if (Array.isArray(parsed)) parsed = parsed[0];

        const cleanBrackets = (val: any) => (typeof val === "string" ? val.replace(/[\[\]]/g, "").trim() : val);

        diagnosisResult = {
          score: parsed.score || 0,
          grade: cleanBrackets(parsed.grade) || "E",
          rank_name: cleanBrackets(parsed.rank_name) || "判定不能",
          warning: cleanBrackets(parsed.warning) || "...",
          comment: cleanBrackets(parsed.comment) || "解析できませんでした...",
        };

      } catch (geminiError) {
        console.error("Gemini/Parse Error:", geminiError);
        // Geminiのエラー時もエラーデータをセット
        diagnosisResult = createErrorData();
      }
    }

    // 4. DB保存 & レスポンス返却 (共通処理)
    if (!diagnosisResult) {
      diagnosisResult = createErrorData();
    }

    // 画像URLの決定
    const selectedImageUrl = RANK_IMAGE_URLS[diagnosisResult.grade] || RANK_IMAGE_URLS["E"];

    // DB保存
    const { data: dbData, error: dbError } = await supabase
      .from("diagnoses")
      .insert({
        question: question || "不明",
        answer: answer || "不明",
        score: diagnosisResult.score,
        grade: diagnosisResult.grade,
        rank_name: diagnosisResult.rank_name,
        comment: diagnosisResult.comment,
        warning: diagnosisResult.warning,
        image_url: selectedImageUrl
      })
      .select()
      .single();

    if (dbError) throw dbError;

    // 成功として200を返す（中身がErrorグレードの場合もある）
    return NextResponse.json({
      ...diagnosisResult,
      id: dbData.id,
      image_url: selectedImageUrl
    });

  } catch (fatalError: any) {
    console.error("Fatal Error:", fatalError);
    // DB保存すらできなかった場合の最終手段（ここだけは500を返す）
    return NextResponse.json({ 
      error: "診断失敗", 
      details: "予期せぬエラーが発生しました。" 
    }, { status: 500 });
  }
}